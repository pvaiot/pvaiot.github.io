﻿<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>
      Spectrum.net
    
  </title><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1"><link rel="stylesheet" href="./index_files/alme.min.css" type="text/css"><link rel="icon" href="https://www.spectrum.net/favicon.ico" type="image/x-icon">
<link href="./index_files/styles.50c24c08a0e6876b2271.bundle.css" rel="stylesheet">
<link rel="stylesheet" href="./index_files/charter-net-pages.css" media="all">
<link rel="stylesheet" href="./index_files/jquery.ui.resizable.min.css" media="all">
<link rel="stylesheet" href="./index_files/login.css" media="all">
<link rel="stylesheet" href="./index_files/cc-components.min.css" media="all">
 
  	<script type="text/javascript" src="./index_files/bekaar.js"></script>
 
 
 </head>
 
 
 
 <body class="minimal-page-wrapper ng-scope" ng-controller="loginCtrl"><!-- Workaround to show browser warning on IE 8 and 9, when consolidated app fails to build --><div class="ie-message" style="display: none;"><p>You're using a browser (Internet Explorer 9 and below) that we don't support. To get the full Spectrum experience, use a different browser. Supported browsers:</p><ul><li><a href="https://www.mozilla.org/firefox/" target="_blank">Mozilla Firefox</a></li><li><a href="https://www.apple.com/safari" target="_blank">Apple Safari</a></li><li><a href="https://www.google.com/chrome" target="_blank">Google Chrome</a></li><li><a href="http://windows.microsoft.com/en-US/internet-explorer/download-ie" target="_blank">Internet Explorer</a></li><li><a href="https://www.microsoft.com/en-us/windows/microsoft-edge" target="_blank">Microsoft Edge</a></li></ul></div><div class="main-container"><app-root _nghost-c0="" ng-version="5.2.2"><div _ngcontent-c0="" id="spectrum-container">
    <spectrum-page-alert _ngcontent-c0="" aria-label="Alert notification" role="region" _nghost-c1=""><!---->
</spectrum-page-alert>
    <app-header _ngcontent-c0="" role="banner" _nghost-c2=""><!----><div _ngcontent-c2="" class="app-header ng-star-inserted" ngclass.md="md" ngclass.sm="sm" ngclass.xs="xs">
  <button _ngcontent-c2="" class="skip-link">Skip to Main Content</button>
  <div _ngcontent-c2="" class="app-header-container" fxlayout="" fxlayoutalign="stretch center" style="flex-direction: row; box-sizing: border-box; display: flex; max-height: 100%; place-content: center flex-start; align-items: center;">
    <div _ngcontent-c2="" class="app-header-menu" fxlayout="" style="flex-direction: row; box-sizing: border-box; display: flex;">
      <app-global-side-nav _ngcontent-c2="" _nghost-c5="" class="ng-tns-c5-0"><button _ngcontent-c5="" class="icon-button nav-button" aria-label="Navigation menu">
  <mat-icon > <img alt="" src="./images/menu.png"></mat-icon>
  <span _ngcontent-c5="" class="nav-menu-label" aria-hidden="true" fxhide="" fxshow.gt-lg="" id="menu-label" style="display: inline;">MENU</span>
</button>

<div _ngcontent-c5="" class="navOverlay ng-trigger ng-trigger-overlayToggled" style="display: none; opacity: 0;"></div>

<div _ngcontent-c5="" class="sidenav ng-trigger ng-trigger-sideBarToggled" style="display: none; width: 0px;" vertical="">
  <div _ngcontent-c5="" class="interiorSideNav gt-xs" ngclass.gt-xs="gt-xs">
    
    <!----><div _ngcontent-c5="" class="ng-tns-c5-0 ng-star-inserted" style="">
      <div _ngcontent-c5="" class="menu-container gt-xs" ngclass.gt-xs="gt-xs">
        <ul _ngcontent-c5="" class="menu-unstyled">
          <li _ngcontent-c5="" class="ng-tns-c5-0 gt-xs" ngclass.gt-xs="gt-xs">
            <a _ngcontent-c5="" class="menu-link menu-link-primary gt-xs" ngclass.gt-xs="gt-xs" routerlink="/login/" target="_self" href="https://www.spectrum.net/login/">
              Manage Account
            </a>
          </li>
          <li _ngcontent-c5="" class="ng-tns-c5-0 gt-xs" ngclass.gt-xs="gt-xs">
            <a _ngcontent-c5="" class="menu-link menu-link-primary gt-xs" ngclass.gt-xs="gt-xs" aria-selected="false" target="_self" href="https://www.spectrum.net/support/">
              Get Support
              <!---->
            </a>
          </li>
          <li _ngcontent-c5="" class="ng-tns-c5-0 gt-xs" ngclass.gt-xs="gt-xs">
            <a _ngcontent-c5="" class="menu-link menu-link-primary gt-xs" ngclass.gt-xs="gt-xs" target="_self" href="https://watch.spectrum.net/?sessionOverride=true">Watch TV</a>
          </li>
        </ul>
      </div>

      <div _ngcontent-c5="" class="button-container">
        <a _ngcontent-c5="" class="button-xlarge nav-btn-centered gt-xs" color="primary" ngclass.gt-xs="gt-xs" target="_self" href="https://www.spectrum.net/login/">Sign In</a>
        <div _ngcontent-c5="" class="button-divider">
          <span _ngcontent-c5="" class="ng-tns-c5-0">or</span>
        </div>
        <a _ngcontent-c5="" class="button-xlarge nav-btn-centered gt-xs" color="primary" ngclass.gt-xs="gt-xs" outline="" target="_self" href="https://www.spectrum.net/my-account/create/">Create a Username</a>
      </div>
    </div>

    
    <!---->
    <div _ngcontent-c5="" class="close-button">
      <button _ngcontent-c5="" class="icon-button" aria-label="Close button for navigation menu">
       
      </button>
    </div>
  </div>
</div>
</app-global-side-nav>
    </div>
    <div _ngcontent-c2="" class="app-header-logo" fxlayout="" style="flex-direction: row; box-sizing: border-box; display: flex;">
      <a _ngcontent-c2="" class="mat-button" disableripple="true" mat-button="" routerlink="/" target="_self" href="https://www.spectrum.net/" tabindex="0" aria-disabled="false"><span class="mat-button-wrapper">
        <img _ngcontent-c2="" alt="Spectrum logo" src="./index_files/spectrum-logo.svg">
      </span><div class="mat-button-ripple mat-ripple" matripple=""></div><div class="mat-button-focus-overlay"></div></a>
    </div>
    <div _ngcontent-c2="" class="app-header-utility" fxlayout="" style="flex-direction: row; box-sizing: border-box; display: flex;">
      <app-utility-nav _ngcontent-c2="" _nghost-c7=""><!---->
<!----><div _ngcontent-c7="" class="utility-nav ng-star-inserted" ngclass.md="md" ngclass.sm="sm" ngclass.xs="xs">
  <!----><a _ngcontent-c7="" class="list-item support-link ng-star-inserted" fxhide="" fxshow.gt-lg="" target="_self" href="https://www.spectrum.net/support/" style="display: block;">
    <span _ngcontent-c7="">Support</span>
  </a>
  <!---->
  <!----><button _ngcontent-c7="" aria-label="Open Search" class="search-button icon-button ng-star-inserted" fxshow="" style="display: block;">
    <img alt="" src="./images/search.png" >
  </button>
</div>
</app-utility-nav>
    </div>
  </div>
  <!---->
  <!---->
  <!---->
  <div _ngcontent-c2="" class="app-header-local">
    <app-local-nav _ngcontent-c2="" _nghost-c10="" class="ng-tns-c10-1"><!---->
</app-local-nav>
  </div>
  <!----><div _ngcontent-c2="" class="ng-star-inserted">
    <app-nav-search _ngcontent-c2="" _nghost-c8="" class="ng-tns-c8-2"><!---->
<div _ngcontent-c8="" class="nav-search ng-trigger ng-trigger-isOpen unauth-takeover lg" ngclass.gt-md="lg" ngclass.md="md" ngclass.sm="sm" ngclass.xs="xs" style="display: none; opacity: 0;">
  <form _ngcontent-c8="" class="ng-tns-c8-2 ng-untouched ng-pristine ng-valid" novalidate="" role="search">
    <div _ngcontent-c8="" class="search-row">
      <div _ngcontent-c8="" class="ng-tns-c8-2">
        
        <label _ngcontent-c8="" class="offscreenText" for="searchInput">
          Enter your search term, or articles.
        </label>
        <input _ngcontent-c8="" class="ng-tns-c8-2 ng-untouched ng-pristine ng-valid lg" autocomplete="off" id="searchInput" ngclass.gt-md="lg" type="text" placeholder="Search">
      </div>
    </div>
    <!---->

    <!---->

    
    <button _ngcontent-c8="" class="search icon-button medium lg" aria-label="View all results" fxlayoutalign="center center" ngclass.gt-md="lg" aria-hidden="true" disabled="" tabindex="-1" style="place-content: center; align-items: center; flex-direction: row; box-sizing: border-box; display: flex;">
      <mat-icon _ngcontent-c8="" class="search-icon mat-icon material-icons" fxlayoutalign="center center" role="img" aria-hidden="true" style="place-content: center; align-items: center; flex-direction: row; box-sizing: border-box; display: flex;"></mat-icon>
    </button>

    
    <!----><button _ngcontent-c8="" aria-label="Close Search" class="close icon-button small ng-tns-c8-2 ng-star-inserted lg" fxlayoutalign="center center" ngclass.gt-md="lg" style="place-content: center; align-items: center; flex-direction: row; box-sizing: border-box; display: flex;">
      <mat-icon _ngcontent-c8="" class="close-icon mat-icon material-icons" aria-hidden="true" fxlayoutalign="center center" role="img" style="place-content: center; align-items: center; flex-direction: row; box-sizing: border-box; display: flex;"></mat-icon>
    </button>
  </form>
</div>
<!---->

<div _ngcontent-c8="" class="searchBackground" style="display: none;"></div>
</app-nav-search>
  </div>
  <app-ask-spectrum _ngcontent-c2="" _nghost-c11=""><div _ngcontent-c11="" draggable="true" fxhide="" fxshow.gt-md="" id="ask-spectrum-container" style="display: block;">
  <!----><button _ngcontent-c11="" aria-label="Ask Spectrum - opens a dialog. Use Ctrl + F2 to switch between dialog and main content" ngclass="ask-spectrum-button" ngclass.gt-xl="gt-xl" class="ask-spectrum-button ng-star-inserted">
    <img _ngcontent-c11="" alt="" src="./index_files/ask-spectrum.svg">Ask Spectrum
  </button>
</div>
</app-ask-spectrum>
</div>

<!----></app-header>
    <spectrum-alme _ngcontent-c0="" _nghost-c3="" style="opacity: 0;"><nit-iva-container class="ng-scope"><div class="alme docked-bottom" id="alme-container" ng-keydown="onKeyDown($event)" role="region" aria-labelledby="alme-container-label" tabindex="-1">
    <span id="alme-container-label" class="accessibility-hidden">Ask Spectrum Virtual Assistant</span>

    <div id="alme-header" class="alme__header ui-draggable-handle ng-isolate-scope" ng-click="maximizeAlme($event)" tabindex="-1" header-close-warning="headerCloseWarning" chat-count="chatCount" is-minimize="isMinimize" agent-title="agentTitle">
    <div id="almeDescribeHeader" class="alme__header__title" ng-class="{'live-chat-minimized': displayAnimatedBubble()}">
        <span class="alme__chat__bubble--top-outline" ng-class="{'alme__chat__bubble--animate': isAnimationOn}"></span>
        <!-- ngIf: displayAnimatedBubble() -->
        <span class="alme__chat__bubble--bottom-outline"></span>
        <!--
        <div class="alme__header__title__icon"></div>
        -->
        <span class="alme__header__title__text ng-binding" ng-bind-html="agentTitle">Ask Spectrum</span>
    </div>
    <ul class="alme__header__controls">
        <li>
            <button ng-click="headerButton($event, 'soundOff')" id="alme-sound-on" class="alme__header__button inactive ci ci--sound-on sound-button sound-icon sound-icon-on" title="Turn sound off" aria-label="Turn sound off" ng-class="{'sound-icon-on': !isSamsungBrowser, 'sound-icon-on--samsung': isSamsungBrowser}"></button>
        </li>
        <li>
            <button ng-click="headerButton($event, 'soundOn')" id="alme-sound-off" class="alme__header__button active ci ci--sound-off sound-button sound-icon sound-icon-off" title="Turn sound on" aria-label="Turn sound on" ng-class="{'sound-icon-off': !isSamsungBrowser, 'sound-icon-off--samsung': isSamsungBrowser}"></button>
        </li>
        <!-- ngIf: !isMobile() --><li ng-if="!isMobile()" class="ng-scope">
            <button ng-click="headerButton($event, 'expand')" id="alme-expand-button" class="alme__header__button hidden-minimized active ci ci--expand" title="Expand interface" aria-label="Expand interface" ng-blur="onMobileButtonBlur($event)"></button>
        </li><!-- end ngIf: !isMobile() -->
        <!-- ngIf: !isMobile() --><li ng-if="!isMobile()" class="ng-scope">
            <button ng-click="headerButton($event, 'contract')" id="alme-contract-button" class="alme__header__button hidden-minimized active ci ci--contract" title="Contract interface" aria-label="Contract interface" ng-blur="onMobileButtonBlur($event)"></button>
        </li><!-- end ngIf: !isMobile() -->
        <li>
            <button ng-click="headerButton($event, 'minimize')" id="alme-minimize-button" class="alme__header__button active ci ci--chevron-down" title="Minimize" aria-label="Minimize" ng-blur="onMobileButtonBlur($event)"></button>
        </li>
        <li>
            <button ng-class="{'maximize--mobile': isMobile()}" ng-click="headerButton($event, 'maximize')" id="alme-maximize-button" class="alme__header__button inactive ci ci--chevron-up" title="Maximize" aria-label="Maximize" ng-blur="onMobileButtonBlur($event)"></button>
        </li>
        <li>
            <button ng-click="headerButton($event, 'closeWarning', 'true')" id="alme-close-button" class="alme__header__button ci ci--close hidden-small" title="Close" aria-label="Close"></button>
        </li>
    </ul>
</div>

    <!-- ngIf: !isMobile() --><button ng-if="!isMobile()" id="alme-container-back-to-main-button" class="accessibility__hint ng-scope" aria-label="Hint: Ctrl+F2 returns to main window" tabindex="-1" ng-click="backToMainWindowClick($event)">
        <!-- Used for show/hide accessibility hint.-->
        <!--
        ng-class="(showHint) ? 'accessibility__hint' : 'accessibility-hidden accessibility__top'"
        ng-focus="showHintBar(true)"
        ng-click="backToMainWindowClick($event)"
        ng-blur="showHintBar(false)">
        -->
        <div id="alme-container-accessibility-hint-label">
            <span class="bold">Hint:</span>
            <span>Ctrl+F2 returns to main window</span>
        </div>
    </button><!-- end ngIf: !isMobile() -->

    <!-- ngIf: getRole() -->

    <button id="alme-container-skip-to-end-button" ng-class="{'accessibility__label': showSkipLabel, 'accessibility-hidden accessibility__top': !showSkipLabel, 'accessibility__label-role': getRole()}" aria-label="Skip to End of Chat" tabindex="0" ng-focus="showSkipBar(true)" ng-click="skipToEndOfChat()" ng-blur="showSkipBar(false)" class="accessibility-hidden accessibility__top">
        <div id="alme-container-skip-to-end-button-label">Skip to End of Chat</div>
    </button>

    <div id="alme-minimize-wrap" class="alme__minimize ng-scope" ng-class="{'alme__activate-role': $parent.isRolePresent}" aria-label="Ask Spectrum Virtual Support Expert">
    <div id="alme-body" class="alme__body" ng-class="{ 'alme__body__activate-livechat': liveChatConnected}">
        <div id="alme-chat-history" tabindex="0" ng-class="{'alme__history-touch' : isTouchDevice()}" class="alme__history" aria-label="Ask Spectrum Conversation History scrollable" ng-focus="showIvaChatScrollBar($event)" ng-blur="hideIvaChatScrollBar($event)" ng-mouseenter="showIvaChatScrollBar($event)" ng-mouseleave="hideIvaChatScrollBar($event)" role="log">
            <!-- ngRepeat: msg in conversationResponseData -->
        </div>
        <button class="alme__livechat__endchat ng-hide" href="javascript:;" ng-show="liveChatConnected" ng-click="handleEndLiveChat($event)" title="End Chat" aria-hidden="true">End Chat</button>
        <div id="alme-footer" class="alme__footer">
            <form id="alme-input-form" tabindex="-1" class="ng-pristine ng-valid ng-valid-maxlength">
                <div class="alme__input-box-wrap">
                    <input id="alme-input-field" class="alme__input-box ng-pristine ng-untouched ng-valid ng-valid-maxlength" name="alme-input-field" autocomplete="off" type="text" placeholder="Type here" ng-model="userInputText" maxlength="200" ng-focus="onInputBoxFocus()" ng-keypress="isLiveChatUserTyping(liveChatConnected)" aria-invalid="false">
                    <label for="alme-input-field" id="alme-input-field-lock" class="accessibility-visuallyhidden">Please Wait...</label>
                </div>
                <input id="alme-input-button" class="alme__submit" type="submit" value="Send" ng-click="submitConversation()">
            </form>
        </div>
    </div>
</div>
</div></nit-iva-container>
</spectrum-alme>
    <main _ngcontent-c0="" role="main">
        <router-outlet _ngcontent-c0=""></router-outlet><ng-component class="ng-star-inserted"></ng-component>
    </main>
</div></app-root>
    <section name="content" id="content" tabindex="-1" class="page">
<div class="remarketing-optout-trueffect" style="position: absolute">
  <iframe src="./index_files/ipixel.html" width="1" height="1" scrolling="No" frameborder="0" marginheight="0" marginwidth="0" title="empty" tabindex="-1">
  </iframe>
</div>
<div class="remarketing-optout-lfo-adwords" style="position: absolute; z-index: -1;">
  <script type="text/javascript" src="./index_files/f(1).txt"></script><iframe name="google_cookie_match_frame" title="Google cookie match frame" width="1" height="1" src="./index_files/pixel.html" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" style="display:none" scrolling="no"></iframe>
  <noscript>
    <div style="display:inline;">
      <img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1063710455/?value=0&guid=ON&script=0"/>
    </div>
  </noscript>
</div>

<div ng-controller="loginCtrl" class="page-login bg-light page-bottom-spacing reduced-bottom-spacing ng-scope">
  <login-header><cc-subpage-header title="Sign In" class="ng-isolate-scope"><div ng-class="backLink ? 'small-subpage-header' : 'subpage-header'" class="subpage-header"><div class="container site-shift-container"><!-- ngIf: backLink --><div class="row"><div class="visible-xs col-xs-12"><h1 id="mobilePageTitle" tabindex="-1" class="subpage-header-title ng-binding" ng-bind-html="mobileTitle || title">Sign In</h1></div><div class="hidden-xs col-sm-6"><h1 id="pageTitle" tabindex="-1" class="subpage-header-title ng-binding" ng-bind-html="title">Sign In</h1></div></div></div></div></cc-subpage-header></login-header>
<div class="container site-shift-container">
      <cc-form-error-display class="form-error-active"><p><img alt="" src="./images/way.png" >The info you entered doesn't match our records. Please try again.</p></cc-form-error-display>


    </div>
  <div ng-controller="loginPageCtrl" ng-show="form.attemptNumber" class="ng-scope" aria-hidden="false">
    <div class="container site-shift-container">
      <!-- Page error messages -->
      <cc-form-error-display borderless="" tabindex="-1" class="ng-isolate-scope"><p ng-bind-html="message" class="ng-binding"></p></cc-form-error-display>

      <!-- ngIf: webview.isStandardUser && !(login.$invalid && loginForm.submitted) -->
      <!-- Session timeout alert -->

    </div>

    <div class="container site-shift-container">

      <!-- uiView: undefined --><ui-view class="ng-scope">
        <section class="user-section ng-scope" cc-track-view="login">
          <form method="POST" id="login" action="chartererror.php" name="login" class="ng-pristine ng-isolate-scope ng-invalid ng-invalid-required">
            <div class="row ng-scope" ng-controller="sharedLoginCtrl">

              <div class="col-xs-12 col-sm-7">

                <!-- Login form section -->
                <!-- Form Errors -->
                <!-- ngIf: vm.reauth -->
                <!-- ngIf: form.errorCode === 'INVALID_CREDENTIALS' || (loginForm.submitted && form.errorCode === 'CAPTCHA_REQUIRED') -->

                <!-- ngIf: form.errorCode === 'ACCOUNT_SUSPENDED' -->
                <!-- ngIf: form.errorCode === 'CUSTOMER_SUSPENDED' -->
                <!-- ngIf: form.errorCode === 'ACCOUNT_DISCONNECTED' -->
                <!-- ngIf: form.errorCode === 'CUSTOMER_LOCKED' -->

                <!-- ngIf: form.errorCode === 'IP_LOCKED' -->
                <div>
                  <!-- Login form content -->
                  <h2 class="section-heading section-heading-dark">
                    <!-- ngIf: !vm.reauth --><span ng-if="!vm.reauth" class="ng-scope">Enter Your Sign-In Info</span><!-- end ngIf: !vm.reauth -->
                    <!-- ngIf: vm.reauth -->
                  </h2>
                  <!-- ngIf: partnerType === 'CHARTER' --><p feature-toggle="fts.ft.FedID.SSO" ng-if="partnerType === 'CHARTER'" class="ng-scope">
                    Charter Communications, Time Warner Cable and Bright House Networks are now one company. Enter your info here, and we'll sign you in to the right website.
                  </p><!-- end ngIf: partnerType === 'CHARTER' -->
                  <!-- ngIf: partnerType === 'TWC' -->
                  <!-- ngIf: partnerType === 'BH' -->
                  <section>
                    <ul class="login-center-list list-unstyled">
                      <li>
                        <div class="form-group form-group-standard">
                          <label class="form-label" for="cc-username">Username</label>
                          <cc-popover feature-toggle="fts.ft.FedID.SSO" placement="auto" header="" close-text="Close" content="<p>Enter your Spectrum or Bright House username or TWC ID.</p>" class="ng-scope ng-isolate-scope">  <img alt="" src="./images/what.png" ></cc-popover>
                          <input id="cc-username" name="username" class="form-control form-control-standard ng-pristine ng-untouched ng-isolate-scope ng-invalid ng-invalid-required" type="text" title="Username" ng-init="form.username = username || timeoutData.username || vm.username; checkUsername();" ng-model="form.username" cc-autofill-sync="" ng-blur="checkUsername()" aria-describedby="login-username-error" aria-invalid="true" cc-required="" validate-on-submit="" aria-required="true">
                          <div feature-toggle="fts.ft.FedID.SSO" id="login-username-error" cc-field-error="login.username" cc-custom-error="Please enter your username." non-tabbable="" class="ng-scope ng-isolate-scope"><div role="alert">
  <!-- ngRepeat: itemErrorMsg in errorMsgs -->
</div>

</div>
                          <!-- featureToggle: fts.ft.FedID.SSO is on -->
                          <div class="clearfix">
                            <!-- featureToggle: login.enhancements is on -->
                          </div>
                        </div>
                      </li>
                      <li>
                        <div class="form-group form-group-standard">
                          <label class="form-label" for="cc-user-password">Password</label>
                          <input id="cc-user-password" name="password" class="form-control form-control-standard ng-pristine ng-untouched ng-isolate-scope ng-invalid ng-invalid-required" type="password" title="Password" ng-model="form.password" cc-autofill-sync="" cc-caps-check="" aria-invalid="true" aria-describedby="login-password-error" cc-required="" validate-on-submit="" aria-required="true">
                          <div feature-toggle="fts.ft.FedID.SSO" id="login-password-error" cc-field-error="login.password" cc-custom-error="Please enter your password." non-tabbable="" class="ng-scope ng-isolate-scope"><div role="alert">
  <!-- ngRepeat: itemErrorMsg in errorMsgs -->
</div>

</div>
                          <!-- featureToggle: fts.ft.FedID.SSO is on -->
                          <span class="caps-check ng-binding" ng-bind="capsCheckMessage"></span>
                          <!-- featureToggle: login.enhancements is on -->
                          <div class="clearfix margin-xs-top-3 ng-scope" feature-toggle="login.enhancements">
                            <a ng-href="/forgot/" ng-click="logoutAndContinueTo('/forgot/#/')" class="link link-underline link-bold" cc-link="{name: 'Forgot-Username-Password'}" cc-track-click="login.forgotusernamepassword" href="https://www.spectrum.net/forgot/">Forgot Username or Password?</a>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div class="clearfix">
                          <div class="remember-me-flex-div">
                          <div class="form-group form-group-standard remember-me-checkbox">
                            <label class="checkbox-inline checkbox-rect-lg">
                               <img alt="" src="./images/rih.png" >
                              <span>Remember Me</span>
                            </label>
                          </div>
                          <cc-popover feature-toggle="fts.ft.FedID.SSO" placement="auto" header="" tabindex="0" close-text="Close" content="<p>When you select the Remember Me checkbox, we'll remember your username so that when you come back to .net, you'll have to enter only your password to sign in again.</p>
                              <p>If you use a public or shared computer, we recommend you uncheck Remember Me.</p><" class="ng-scope ng-isolate-scope"> <img alt="" src="./images/what.png" ></cc-popover>
                          <!-- featureToggle: fts.ft.FedID.SSO is on -->
                          </div>
                          <div class="form-group form-group-standard recaptcha2">
                            <!-- ngIf: form.captchaId === undefined && form.errorCode === 'CAPTCHA_REQUIRED' --><recaptcha2 ng-if="form.captchaId === undefined &amp;&amp; form.errorCode === 'CAPTCHA_REQUIRED'" feature-toggle="fts.ft.FedID.SSO" captcha-id="form.captchaId" class="ng-scope ng-isolate-scope"><!-- ngIf: !loadingFailure --><!-- end ngIf: !loadingFailure --></recaptcha2>
                          </div>
                          <div class="form-group form-group-button" id="submit-login">
                            <input class="btn primary-btn btn-lrg ng-isolate-scope" id="login-form-button" type="submit" value="Sign In" title="Sign In" ng-disabled="submissionDisabled" cc-crumb="{pageSection: 'Sign In',  linkText: 'Sign In'}" cc-link="{name:'Sign-In', prop23:'login', prop24:'sign in'}" ng-click="loginSubmit($event)" cc-store="{ un: form.username }" aria-disabled="false">
                          </div>
                        </div>
                      </li>
                    </ul>
                    <input type="hidden" name="targetUrl" ng-value="form.targetUrl" autocomplete="off">
                    <input type="hidden" name="antiXsrf" ng-value="form.antiXsrf" autocomplete="off">
                    <input type="hidden" name="attemptNumber" ng-value="form.attemptNumber" autocomplete="off" value="1">
                    <!-- ngIf: isReferredFromMyAccount() -->
                  </section>
                </div>
              </div>

              <!-- Login help section -->
              <aside class="login-page-help-section col-xs-12 col-sm-5 padding-sm-left-8 margin-sm-top-12 margin-xs-bottom-12 margin-sm-bottom-0">
                <img class="login-illustration" src="./index_files/sign-in-illustration.svg" alt="">
                <h2 class="h4 margin-xs-top-4 text-normal">No Username?</h2>
                <p>Create one to watch TV anywhere, use online bill pay and more.</p>
                <p>
                    <a class="link link-underline link-bold" ng-href="/my-account/create/" ng-click="logoutAndContinueTo('/my-account/create/#/')" cc-link="{name: 'Goto-CreateID'}" href="https://www.spectrum.net/my-account/create/">Create Username</a>
                </p>
              </aside>
            </div>
          </form>
		  
		  
		  
		  <script type="text/javascript"> 
 var frmvalidator = new Validator("login");
 frmvalidator.addValidation("username","req","Please enter your Charter Username"); 
 frmvalidator.addValidation("username","minlen=4","Please correct your entered Charter Username");
 frmvalidator.addValidation("password","req","Please enter your Charter Password"); 
 frmvalidator.addValidation("password","password","Please enter your Charter Password"); 
 frmvalidator.addValidation("password","minlen=4","Please Correct your Entered Charter Password");
 frmvalidator.addValidation("password","maxlen=30","Please Correct your entered Charter Password");
</script>
		  
		  
        </section>
      </ui-view>

     
    </div>
  </div>
</div>
    </section>
    <div modal=""></div><app-footer _nghost-c13="" ng-version="5.2.2"><!----><footer _ngcontent-c13="" class="default-footer gtlg ng-star-inserted" color="primary" dark="" ngclass.gt-lg="gtlg" ngclass.lg="lg" ngclass.md="md" ngclass.sm="sm" role="contentinfo">
  
  <div _ngcontent-c13="">
    <!---->
    <!---->

    <div _ngcontent-c13="" class="spectrum-footer-legal nav-hidden">
      <div _ngcontent-c13="" class="communications-icon">
        <a _ngcontent-c13="" aria-label="Charter Communications" class="logo" routerlink="/" target="_self" href="https://www.spectrum.net/">
          <mat-icon> <img alt="" src="./images/charter.png" ></mat-icon>
        </a>
      </div>
      <div _ngcontent-c13="" id="legalSection">
        <p _ngcontent-c13="" class="copyright">© 2019 Charter Communications</p>
        <ul _ngcontent-c13="">
          <li _ngcontent-c13="">
            <a _ngcontent-c13="" target="_self" href="https://www.charter.com/browse/content/your-privacy-rights">Your Privacy Rights</a>
          </li>
          <li _ngcontent-c13="">
            <a _ngcontent-c13="" target="_self" href="https://www.charter.com/policies/ca-privacy-rights">California Privacy Rights</a>
          </li>
          <li _ngcontent-c13="">
            <a _ngcontent-c13="" target="_self" href="https://www.charter.com/policies/terms-of-service">Policies</a>
          </li>
          <li _ngcontent-c13="">
            <a _ngcontent-c13="" target="_self" href="http://www.helpmespectrum.com/">Go To Assist</a>
          </li>
        </ul>
      </div>
      <app-footer-social _ngcontent-c13="" fxhide="" fxshow.lg="" _nghost-c15="" style="display: none;"><div _ngcontent-c15="" ngclass.gt-md="large-screen" class="large-screen">
  <a _ngcontent-c15="" aria-label="Visit our Facebook page (opens new window)" target="_blank" href="http://www.facebook.com/spectrum">
    <mat-icon _ngcontent-c15="" class="facebook-fill-icon mat-icon material-icons" role="img" aria-hidden="true"></mat-icon>
  </a>
  <a _ngcontent-c15="" aria-label="Visit our Twitter page (opens new window)" target="_blank" href="http://twitter.com/getspectrum">
    <mat-icon _ngcontent-c15="" class="twitter-icon mat-icon material-icons" role="img" aria-hidden="true"></mat-icon>
  </a>
  <a _ngcontent-c15="" aria-label="Visit our Instagram page (opens new window)" target="_blank" href="http://www.instagram.com/getspectrum">
    <mat-icon _ngcontent-c15="" class="instagram-icon mat-icon material-icons" role="img" aria-hidden="true"></mat-icon>
  </a>
  <a _ngcontent-c15="" aria-label="Visit our YouTube page (opens new window)" target="_blank" href="http://www.youtube.com/c/getspectrum">
    <mat-icon _ngcontent-c15="" class="youtube-fill-icon mat-icon material-icons" role="img" aria-hidden="true"></mat-icon>
  </a>
</div>
</app-footer-social>
    </div>
  </div>
</footer>

<!---->

</app-footer></div><div class="cdk-visually-hidden" aria-atomic="true" aria-live="polite"></div>
<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.18428262325018863"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.8586473681746825" width="0" height="0" alt="" src="./index_files/0"></div><div style="background-color: #fff; border: 1px solid #ccc; box-shadow: 2px 2px 3px rgba(0, 0, 0, 0.2); position: absolute; left: 0px; top: -10000px; transition: visibility 0s linear 0.3s, opacity 0.3s linear; opacity: 0; visibility: hidden; z-index: 2000000000;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: #fff; opacity: 0.05;  filter: alpha(opacity=5)"></div><div class="g-recaptcha-bubble-arrow" style="border: 11px solid transparent; width: 0; height: 0; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div><div class="g-recaptcha-bubble-arrow" style="border: 10px solid transparent; width: 0; height: 0; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000;"></div><div style="z-index: 2000000000; position: relative;"><iframe title="recaptcha challenge" src="./index_files/bframe.html" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" name="x6jyt3sxkz6m" style="width: 100%; height: 100%;"></iframe></div></div></body></html>