<?php
include 'lang/en.php'; // u can add any langue edit file lang/en.php    //.
?>